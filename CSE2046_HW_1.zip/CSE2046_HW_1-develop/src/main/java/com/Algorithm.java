package com;

import java.util.List;

public interface Algorithm {
    public abstract int findK(List<Integer> arr, int k);
}
